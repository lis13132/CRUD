package com.example.websocketdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
